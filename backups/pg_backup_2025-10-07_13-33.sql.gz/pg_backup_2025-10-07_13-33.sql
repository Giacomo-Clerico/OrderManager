--
-- PostgreSQL database dump
--

\restrict LT9PoGdGR7qvcqVqdFYSx1tcxcPSOuFm2EQbDjZzWrAd2dBpvvY6v02aqPhjwMu

-- Dumped from database version 15.13 (Debian 15.13-1.pgdg120+1)
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action_text_rich_texts; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.action_text_rich_texts (
    id bigint NOT NULL,
    name character varying NOT NULL,
    body text,
    record_type character varying NOT NULL,
    record_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.action_text_rich_texts OWNER TO admin;

--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.action_text_rich_texts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.action_text_rich_texts_id_seq OWNER TO admin;

--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.action_text_rich_texts_id_seq OWNED BY public.action_text_rich_texts.id;


--
-- Name: active_storage_attachments; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.active_storage_attachments (
    id bigint NOT NULL,
    name character varying NOT NULL,
    record_type character varying NOT NULL,
    record_id bigint NOT NULL,
    blob_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.active_storage_attachments OWNER TO admin;

--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.active_storage_attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.active_storage_attachments_id_seq OWNER TO admin;

--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.active_storage_attachments_id_seq OWNED BY public.active_storage_attachments.id;


--
-- Name: active_storage_blobs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.active_storage_blobs (
    id bigint NOT NULL,
    key character varying NOT NULL,
    filename character varying NOT NULL,
    content_type character varying,
    metadata text,
    service_name character varying NOT NULL,
    byte_size bigint NOT NULL,
    checksum character varying,
    created_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.active_storage_blobs OWNER TO admin;

--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.active_storage_blobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.active_storage_blobs_id_seq OWNER TO admin;

--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.active_storage_blobs_id_seq OWNED BY public.active_storage_blobs.id;


--
-- Name: active_storage_variant_records; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.active_storage_variant_records (
    id bigint NOT NULL,
    blob_id bigint NOT NULL,
    variation_digest character varying NOT NULL
);


ALTER TABLE public.active_storage_variant_records OWNER TO admin;

--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.active_storage_variant_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.active_storage_variant_records_id_seq OWNER TO admin;

--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.active_storage_variant_records_id_seq OWNED BY public.active_storage_variant_records.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO admin;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.comments (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    user_id bigint NOT NULL,
    body text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.comments OWNER TO admin;

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.comments_id_seq OWNER TO admin;

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: delivery_notes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.delivery_notes (
    id bigint NOT NULL,
    recieved_by_id bigint NOT NULL,
    body text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    company text,
    order_id bigint NOT NULL,
    po_number character varying,
    quote_id bigint NOT NULL
);


ALTER TABLE public.delivery_notes OWNER TO admin;

--
-- Name: delivery_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.delivery_notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.delivery_notes_id_seq OWNER TO admin;

--
-- Name: delivery_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.delivery_notes_id_seq OWNED BY public.delivery_notes.id;


--
-- Name: goods; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.goods (
    id bigint NOT NULL,
    delivery_note_id bigint NOT NULL,
    quantity integer,
    location character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    product_id bigint NOT NULL,
    storage_id bigint NOT NULL,
    storage_type character varying NOT NULL
);


ALTER TABLE public.goods OWNER TO admin;

--
-- Name: goods_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.goods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.goods_id_seq OWNER TO admin;

--
-- Name: goods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.goods_id_seq OWNED BY public.goods.id;


--
-- Name: issue_slip_articles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.issue_slip_articles (
    id bigint NOT NULL,
    issue_slip_id bigint NOT NULL,
    product_id bigint NOT NULL,
    quantity integer NOT NULL,
    storage_id bigint NOT NULL,
    location character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.issue_slip_articles OWNER TO admin;

--
-- Name: issue_slip_articles_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.issue_slip_articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.issue_slip_articles_id_seq OWNER TO admin;

--
-- Name: issue_slip_articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.issue_slip_articles_id_seq OWNED BY public.issue_slip_articles.id;


--
-- Name: issue_slips; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.issue_slips (
    id bigint NOT NULL,
    number character varying NOT NULL,
    order_id bigint NOT NULL,
    created_by_id bigint NOT NULL,
    issued boolean DEFAULT false,
    issued_at timestamp(6) without time zone,
    issued_by_id bigint,
    collected_by_id bigint,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.issue_slips OWNER TO admin;

--
-- Name: issue_slips_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.issue_slips_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.issue_slips_id_seq OWNER TO admin;

--
-- Name: issue_slips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.issue_slips_id_seq OWNED BY public.issue_slips.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.items (
    id bigint NOT NULL,
    quote_id bigint NOT NULL,
    price integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    currency character varying(3),
    selected boolean,
    recommended boolean,
    product_id bigint NOT NULL
);


ALTER TABLE public.items OWNER TO admin;

--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.items_id_seq OWNER TO admin;

--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: manual_entries; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.manual_entries (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    storage_type character varying NOT NULL,
    storage_id bigint NOT NULL,
    location character varying,
    quantity integer,
    user_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.manual_entries OWNER TO admin;

--
-- Name: manual_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.manual_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.manual_entries_id_seq OWNER TO admin;

--
-- Name: manual_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.manual_entries_id_seq OWNED BY public.manual_entries.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    name text,
    description text,
    "time" timestamp without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id bigint NOT NULL,
    checked_by_id bigint,
    checked_at timestamp(6) without time zone,
    checked boolean,
    quotes_submitted_at timestamp without time zone,
    quotes_submitted_by_id bigint,
    approved character varying,
    approved_by_id bigint,
    approved_at timestamp without time zone,
    status integer DEFAULT 0
);


ALTER TABLE public.orders OWNER TO admin;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO admin;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.payments (
    id bigint NOT NULL,
    company character varying,
    body text,
    bank character varying,
    account character varying,
    paid_by_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    order_id bigint NOT NULL,
    amount integer,
    from_account text,
    currency character varying(3),
    quote_id bigint NOT NULL
);


ALTER TABLE public.payments OWNER TO admin;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.payments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO admin;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.products (
    id bigint NOT NULL,
    code character varying NOT NULL,
    desctription character varying,
    category character varying NOT NULL,
    product_type character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.products OWNER TO admin;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO admin;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.quotes (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    company text,
    company_address text,
    body text,
    requested_by_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    po_number character varying,
    buy_as character varying
);


ALTER TABLE public.quotes OWNER TO admin;

--
-- Name: quotes_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.quotes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.quotes_id_seq OWNER TO admin;

--
-- Name: quotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.quotes_id_seq OWNED BY public.quotes.id;


--
-- Name: requests; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.requests (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    product_id bigint NOT NULL,
    quantity integer NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.requests OWNER TO admin;

--
-- Name: requests_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.requests_id_seq OWNER TO admin;

--
-- Name: requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.requests_id_seq OWNED BY public.requests.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO admin;

--
-- Name: stocks; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.stocks (
    id bigint NOT NULL,
    product_id bigint NOT NULL,
    quantity integer NOT NULL,
    storage_type character varying NOT NULL,
    storage_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    location character varying
);


ALTER TABLE public.stocks OWNER TO admin;

--
-- Name: stocks_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.stocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stocks_id_seq OWNER TO admin;

--
-- Name: stocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.stocks_id_seq OWNED BY public.stocks.id;


--
-- Name: storages; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.storages (
    id bigint NOT NULL,
    name character varying NOT NULL,
    abbreviation character varying NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.storages OWNER TO admin;

--
-- Name: storages_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.storages_id_seq OWNER TO admin;

--
-- Name: storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.storages_id_seq OWNED BY public.storages.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp(6) without time zone,
    remember_created_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_type character varying
);


ALTER TABLE public.users OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO admin;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: action_text_rich_texts id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.action_text_rich_texts ALTER COLUMN id SET DEFAULT nextval('public.action_text_rich_texts_id_seq'::regclass);


--
-- Name: active_storage_attachments id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.active_storage_attachments ALTER COLUMN id SET DEFAULT nextval('public.active_storage_attachments_id_seq'::regclass);


--
-- Name: active_storage_blobs id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.active_storage_blobs ALTER COLUMN id SET DEFAULT nextval('public.active_storage_blobs_id_seq'::regclass);


--
-- Name: active_storage_variant_records id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.active_storage_variant_records ALTER COLUMN id SET DEFAULT nextval('public.active_storage_variant_records_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: delivery_notes id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.delivery_notes ALTER COLUMN id SET DEFAULT nextval('public.delivery_notes_id_seq'::regclass);


--
-- Name: goods id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.goods ALTER COLUMN id SET DEFAULT nextval('public.goods_id_seq'::regclass);


--
-- Name: issue_slip_articles id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slip_articles ALTER COLUMN id SET DEFAULT nextval('public.issue_slip_articles_id_seq'::regclass);


--
-- Name: issue_slips id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slips ALTER COLUMN id SET DEFAULT nextval('public.issue_slips_id_seq'::regclass);


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: manual_entries id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.manual_entries ALTER COLUMN id SET DEFAULT nextval('public.manual_entries_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: quotes id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.quotes ALTER COLUMN id SET DEFAULT nextval('public.quotes_id_seq'::regclass);


--
-- Name: requests id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.requests ALTER COLUMN id SET DEFAULT nextval('public.requests_id_seq'::regclass);


--
-- Name: stocks id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stocks ALTER COLUMN id SET DEFAULT nextval('public.stocks_id_seq'::regclass);


--
-- Name: storages id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.storages ALTER COLUMN id SET DEFAULT nextval('public.storages_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: action_text_rich_texts; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.action_text_rich_texts (id, name, body, record_type, record_id, created_at, updated_at) FROM stdin;
208	desctription	<div>Donaldson - John Deere - Primary Air Filter - KV6429 - 5090E</div>	Product	20	2025-10-03 15:31:52.513405	2025-10-03 15:31:52.513405
209	desctription	<div>Donaldson - John Deere - Secondary Air Filter - AT171854 - 5090E</div>	Product	21	2025-10-03 15:33:17.485318	2025-10-03 15:33:17.485318
210	desctription	<div>John Deere - Fuel Water Separator - 5090E</div>	Product	22	2025-10-03 15:34:33.291753	2025-10-03 15:34:33.291753
197	desctription	<div>Donaldson - John Deere - primary air filter - AL21505 - 6125M - 6110M</div>	Product	9	2025-10-03 14:50:53.867591	2025-10-03 14:53:58.393309
198	desctription	<div>Donaldson - John Deere - Secondary air filter - AL215054 - 6125M - 6110M</div>	Product	10	2025-10-03 14:55:57.720226	2025-10-03 14:55:57.720226
199	desctription	<div>John Deere - Alternator - 6110M&nbsp;</div>	Product	11	2025-10-03 14:57:20.000549	2025-10-03 14:57:20.000549
200	desctription	<div>Donaldson - Jonh Deere - Transmission oil filter - AL232896 - 6125M&nbsp;</div>	Product	12	2025-10-03 14:59:25.001348	2025-10-03 14:59:25.001348
201	desctription	<div>Donaldson - John Deere - Fuel Filter Element - N378886 - 6125M&nbsp;</div>	Product	13	2025-10-03 15:00:56.668313	2025-10-03 15:00:56.668313
202	desctription	<div>Donaldson - John Deere - Hydraulic Oil Filter - AL221066 - 6225M - 6110M</div>	Product	14	2025-10-03 15:02:28.919952	2025-10-03 15:02:28.919952
204	desctription	<div>John Deere - Cab Air Filter - 6125M&nbsp;</div>	Product	16	2025-10-03 15:05:17.239311	2025-10-03 15:05:17.239311
203	desctription	<div>John Deere - Cabin Air Filter - 6125M</div>	Product	15	2025-10-03 15:04:04.127952	2025-10-03 15:05:55.945618
211	desctription	<div>John Deere - Hydraulic Oil Filter - 5090E</div>	Product	23	2025-10-03 15:35:34.70649	2025-10-03 15:35:34.70649
205	desctription	<div>John Deere - Kingpin - 6110M<action-text-attachment sgid="eyJfcmFpbHMiOnsiZGF0YSI6ImdpZDovL29yZGVyLW1hbmFnZXIvQWN0aXZlU3RvcmFnZTo6QmxvYi85P2V4cGlyZXNfaW4iLCJwdXIiOiJhdHRhY2hhYmxlIn19--753861df9012cfab355566e31639075af542d4ab" content-type="image/jpeg" url="https://localhost:3000/rails/active_storage/blobs/redirect/eyJfcmFpbHMiOnsiZGF0YSI6OSwicHVyIjoiYmxvYl9pZCJ9fQ==--9b1b82f0033399c5e228a7ed602d84d62ce40d3c/Kingpin.jpg" filename="Kingpin.jpg" filesize="52411" width="738" height="1600" presentation="gallery"></action-text-attachment></div>	Product	17	2025-10-03 15:09:11.009696	2025-10-03 15:09:11.746942
206	desctription	<div>Donaldson - John Deere - Fuel Water Separator - RE546336 - 6125M</div>	Product	18	2025-10-03 15:13:44.959108	2025-10-03 15:13:44.959108
207	desctription	<div>Donaldson - John Deere - Fuel Water Separator - RE503198 - RE522868 - RE522987 - RE53400 - 6125M - 5090E</div>	Product	19	2025-10-03 15:20:10.948078	2025-10-03 15:38:15.825604
214	desctription	<div>John Deere - Steering Column Gas Operated Cylinder - 5090E</div>	Product	26	2025-10-03 15:42:59.338158	2025-10-03 15:42:59.338158
215	desctription	<div>John Deere - Electronic Control - 5090E</div>	Product	27	2025-10-03 15:43:59.687594	2025-10-03 15:43:59.687594
216	desctription	<div>Vapormatic - John Deere - Double High Power Clutch - 5090E</div>	Product	28	2025-10-03 15:45:30.660372	2025-10-03 15:45:30.660372
217	desctription	<div>John Deere - Clutch Plate - 5065E</div>	Product	29	2025-10-03 15:46:26.418969	2025-10-03 15:46:26.418969
218	desctription	<div>John Deere - Left Side Front Marker Lamp - 5065E</div>	Product	30	2025-10-03 15:48:13.130986	2025-10-03 15:48:13.130986
219	desctription	<div>John Deere - Secondary Fuel Filter - 5065E</div>	Product	31	2025-10-03 15:49:23.740705	2025-10-03 15:49:23.740705
220	desctription	<div>Donaldson - John Deere - Secondary Fuel Filter - RE60021 - 5065E</div>	Product	32	2025-10-03 15:50:46.32643	2025-10-03 15:50:46.32643
221	desctription	<div>John Deere - Engine Oil Filter - 5065E</div>	Product	33	2025-10-03 15:59:05.58438	2025-10-03 15:59:05.58438
222	desctription	<div>Donaldson - John Deere - Engine Oil Filter - RE519626 - 5065E</div>	Product	34	2025-10-03 16:00:03.35794	2025-10-03 16:00:03.35794
237	desctription	<div>John Deere - Tank Breather - 8R410</div>	Product	45	2025-10-05 11:59:01.254748	2025-10-05 11:59:01.254748
212	desctription	<div>Donaldson - John Deere - Hydraulic Oil Filter - RE45864 - 5090E - 5065E</div>	Product	24	2025-10-03 15:36:47.328922	2025-10-03 16:03:19.576186
213	desctription	<div>Donaldson - John Deere - RE504836 - Engine Oil Filter - 5090E</div>	Product	25	2025-10-03 15:39:55.165021	2025-10-03 16:04:54.282196
223	desctription	<div>Donaldson - John Deere - Secondary Air Filter - SU29301 - 5065E</div>	Product	35	2025-10-03 16:05:49.300207	2025-10-03 16:05:49.300207
224	desctription	<div>John Deere - Secondary Air Filter - 5065E</div>	Product	36	2025-10-03 16:06:39.555564	2025-10-03 16:06:39.555564
225	desctription	<div>Donaldson - John Deere - Primary Air Filter - SU29300 - 5065E</div>	Product	37	2025-10-03 16:08:06.329792	2025-10-03 16:08:06.329792
226	description	<div>clutch&nbsp;</div>	Order	63	2025-10-04 09:04:52.333862	2025-10-04 09:04:52.333862
227	body	<div>asd</div>	Quote	74	2025-10-04 09:05:40.964788	2025-10-04 09:05:40.964788
228	body	<div>asd</div>	Quote	75	2025-10-04 09:06:02.912873	2025-10-04 09:06:02.912873
229	body	<div><br>asd</div>	DeliveryNote	18	2025-10-04 09:07:23.368536	2025-10-04 09:07:23.368536
232	desctription	<div>John Deere - Cab Fresh air filter - 8R410</div>	Product	40	2025-10-05 08:27:21.308034	2025-10-05 08:27:21.308034
231	desctription	<div>John Deere - Hydraulic oil filter - 8R410 - 8R280</div>	Product	39	2025-10-05 08:25:11.294992	2025-10-05 11:33:12.098359
233	desctription	<div>John Deere - Cab Air filter - 8R410 - 8R280</div>	Product	41	2025-10-05 08:28:57.792839	2025-10-05 11:34:34.891678
234	desctription	<div>John Deere - Activated Carbon Cab Fresh Air Filter - 8R410 - 8R280</div>	Product	42	2025-10-05 11:36:09.634509	2025-10-05 11:36:09.634509
235	desctription	<div>John Deere - Fuel Filter - 8R280 - 8R 410</div>	Product	43	2025-10-05 11:40:38.893453	2025-10-05 11:40:38.893453
236	desctription	<div>John Deere - Hydraulic Oil Filter - 8R280 - 8R410</div>	Product	44	2025-10-05 11:48:13.437484	2025-10-05 11:48:13.437484
238	desctription	<div>John Deere - Cab Recirculation Air Filter - 8R410 - 8R280</div>	Product	46	2025-10-05 12:02:45.023442	2025-10-05 12:02:45.023442
239	desctription	<div>John Deere - Secondary Air Filter - 8R410 - 8R280</div>	Product	47	2025-10-05 12:06:37.6999	2025-10-05 12:06:37.6999
240	desctription	<div>John Deere - Cab Air Filter - 8R280&nbsp;</div>	Product	48	2025-10-05 12:15:01.486129	2025-10-05 12:15:01.486129
230	desctription	<div>&nbsp;John Deere - Primary air filter - 8R410 - 8R280</div>	Product	38	2025-10-05 08:23:25.09442	2025-10-05 12:20:46.264429
241	desctription	<div>John Deere - Final Fuel Filter - 8R280 - 8R410</div>	Product	49	2025-10-05 12:22:47.106365	2025-10-05 12:22:47.106365
242	desctription	<div>Donaldson - John Deere - Fianal Fuel Filter - DZ112918 - 8R410 - 8R280</div>	Product	50	2025-10-05 13:47:12.08912	2025-10-05 13:47:12.08912
243	desctription	<div>Donaldson - John Deere - Oil Filter - RE509672 - 8R280 - 8R410</div>	Product	51	2025-10-05 13:49:57.999205	2025-10-05 13:49:57.999205
244	desctription	<div>Donaldson - John Deere - Fuel filter - RE509672 - 8R280 - 8R410</div>	Product	52	2025-10-05 13:54:18.806412	2025-10-05 13:54:18.806412
245	desctription	<div>John Deere - Mid Roller Wheel Spindle - 9570RX</div>	Product	53	2025-10-05 14:04:00.567817	2025-10-05 14:04:00.567817
246	desctription	<div>John Deere - Mid Roller Spindle Cover - 9570RX</div>	Product	54	2025-10-05 14:05:50.552602	2025-10-05 14:05:50.552602
\.


--
-- Data for Name: active_storage_attachments; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.active_storage_attachments (id, name, record_type, record_id, blob_id, created_at) FROM stdin;
8	embeds	ActionText::RichText	205	9	2025-10-03 15:09:11.042258
9	image	ActiveStorage::VariantRecord	4	10	2025-10-03 15:09:11.919837
\.


--
-- Data for Name: active_storage_blobs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.active_storage_blobs (id, key, filename, content_type, metadata, service_name, byte_size, checksum, created_at) FROM stdin;
8	o90jqlp7fipliue7q184si19d117	WP_20140619_024.jpg	image/jpeg	\N	local	530572	QETRxewtCeRGE6iOmwpt/g==	2025-08-29 19:12:28.037676
9	m054yk1vh6emymvnvitcawr19h0t	Kingpin.jpg	image/jpeg	{"identified":true,"width":738,"height":1600,"analyzed":true}	local	52411	E3YbV/cCeSpkOMpAA9Hihg==	2025-10-03 15:08:43.757935
10	kco61rm18cls2r3zolsrepkmgcn6	Kingpin.jpg	image/jpeg	{"identified":true,"width":354,"height":768,"analyzed":true}	local	23289	eq0GK7tYgr7UJ1it2Q8waw==	2025-10-03 15:09:11.911803
\.


--
-- Data for Name: active_storage_variant_records; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.active_storage_variant_records (id, blob_id, variation_digest) FROM stdin;
4	9	g9oDsuZ2Ke1OimlPvx7V2sj306E=
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	production	2025-08-07 17:27:44.009767	2025-08-07 17:27:44.009771
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.comments (id, order_id, user_id, body, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: delivery_notes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.delivery_notes (id, recieved_by_id, body, created_at, updated_at, company, order_id, po_number, quote_id) FROM stdin;
18	1	\N	2025-10-04 09:07:23.361931	2025-10-04 09:07:23.371747	some company	63	POMF250001	74
\.


--
-- Data for Name: goods; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.goods (id, delivery_note_id, quantity, location, created_at, updated_at, product_id, storage_id, storage_type) FROM stdin;
20	18	1	CE01	2025-10-04 09:07:42.355766	2025-10-04 09:07:42.355766	29	4	Storage
\.


--
-- Data for Name: issue_slip_articles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.issue_slip_articles (id, issue_slip_id, product_id, quantity, storage_id, location, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: issue_slips; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.issue_slips (id, number, order_id, created_by_id, issued, issued_at, issued_by_id, collected_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.items (id, quote_id, price, created_at, updated_at, currency, selected, recommended, product_id) FROM stdin;
118	75	120	2025-10-04 09:06:13.974409	2025-10-04 09:06:13.974409	EUR	f	t	29
117	74	12000	2025-10-04 09:05:51.791466	2025-10-04 09:05:51.791466	ZAR	t	f	29
\.


--
-- Data for Name: manual_entries; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.manual_entries (id, product_id, storage_type, storage_id, location, quantity, user_id, created_at, updated_at) FROM stdin;
6	9	Storage	4	CD01	4	1	2025-10-03 14:54:57.829571	2025-10-03 14:54:57.829571
7	10	Storage	4	CD01	4	1	2025-10-03 14:56:27.444398	2025-10-03 14:56:27.444398
8	11	Storage	4	CD01	1	1	2025-10-03 14:57:34.264843	2025-10-03 14:57:34.264843
9	12	Storage	4	CD01	2	1	2025-10-03 14:59:51.658978	2025-10-03 14:59:51.658978
10	13	Storage	4	CD01	3	1	2025-10-03 15:01:22.033171	2025-10-03 15:01:22.033171
11	14	Storage	4	CD01	2	1	2025-10-03 15:03:03.589398	2025-10-03 15:03:03.589398
12	15	Storage	4	CD01	4	1	2025-10-03 15:04:20.679181	2025-10-03 15:04:20.679181
13	16	Storage	4	CD01	2	1	2025-10-03 15:05:33.901853	2025-10-03 15:05:33.901853
14	17	Storage	4	CD01	2	1	2025-10-03 15:09:44.518404	2025-10-03 15:09:44.518404
15	18	Storage	4	CD02	4	1	2025-10-03 15:14:14.115501	2025-10-03 15:14:14.115501
16	19	Storage	4	CD02	4	1	2025-10-03 15:20:30.121866	2025-10-03 15:20:30.121866
17	20	Storage	4	CE01	2	1	2025-10-03 15:32:21.504798	2025-10-03 15:32:21.504798
18	21	Storage	4	CE01	2	1	2025-10-03 15:33:33.800993	2025-10-03 15:33:33.800993
19	22	Storage	4	CE01	2	1	2025-10-03 15:34:51.954918	2025-10-03 15:34:51.954918
20	23	Storage	4	CE01	3	1	2025-10-03 15:35:52.399636	2025-10-03 15:35:52.399636
21	24	Storage	4	CE01	2	1	2025-10-03 15:37:06.446764	2025-10-03 15:37:06.446764
22	19	Storage	4	CE01	2	1	2025-10-03 15:38:55.421907	2025-10-03 15:38:55.421907
23	25	Storage	4	CE01	1	1	2025-10-03 15:40:49.300814	2025-10-03 15:40:49.300814
24	26	Storage	4	CE01	1	1	2025-10-03 15:43:24.30572	2025-10-03 15:43:24.30572
25	27	Storage	4	CE01	1	1	2025-10-03 15:44:17.44446	2025-10-03 15:44:17.44446
26	28	Storage	4	CE01	1	1	2025-10-03 15:45:47.185991	2025-10-03 15:45:47.185991
27	29	Storage	4	CE02	1	1	2025-10-03 15:46:43.409619	2025-10-03 15:46:43.409619
28	30	Storage	4	CE02	1	1	2025-10-03 15:48:37.393678	2025-10-03 15:48:37.393678
29	31	Storage	4	CE02	1	1	2025-10-03 15:49:41.346904	2025-10-03 15:49:41.346904
30	32	Storage	4	CE02	1	1	2025-10-03 15:52:06.181167	2025-10-03 15:52:06.181167
31	33	Storage	4	CE02	1	1	2025-10-03 15:59:24.360544	2025-10-03 15:59:24.360544
32	34	Storage	4	CE02	1	1	2025-10-03 16:00:45.242264	2025-10-03 16:00:45.242264
33	24	Storage	4	CE02	3	1	2025-10-03 16:03:39.993832	2025-10-03 16:03:39.993832
34	35	Storage	4	CE02	1	1	2025-10-03 16:06:14.206411	2025-10-03 16:06:14.206411
35	36	Storage	4	CE02	1	1	2025-10-03 16:07:13.865964	2025-10-03 16:07:13.865964
36	37	Storage	4	CE02	3	1	2025-10-03 16:08:39.676336	2025-10-03 16:08:39.676336
37	29	Storage	4	CE01	-1	1	2025-10-04 09:09:05.456741	2025-10-04 09:09:05.456741
38	42	Storage	4	CC01	1	1	2025-10-05 11:38:34.008587	2025-10-05 11:38:34.008587
39	43	Storage	4	CC01	2	1	2025-10-05 11:47:13.347699	2025-10-05 11:47:13.347699
40	44	Storage	4	CC01	2	1	2025-10-05 11:50:58.967107	2025-10-05 11:50:58.967107
41	45	Storage	4	CC01	2	1	2025-10-05 12:01:10.925829	2025-10-05 12:01:10.925829
42	46	Storage	4	CC01	2	1	2025-10-05 12:05:15.571241	2025-10-05 12:05:15.571241
43	47	Storage	4	CC01	1	1	2025-10-05 12:10:51.061711	2025-10-05 12:10:51.061711
44	46	Storage	4	CC02	2	1	2025-10-05 12:11:37.461642	2025-10-05 12:11:37.461642
45	42	Storage	4	CC02	1	1	2025-10-05 12:12:35.451922	2025-10-05 12:12:35.451922
46	41	Storage	4	CC02	1	1	2025-10-05 12:13:59.669891	2025-10-05 12:13:59.669891
47	48	Storage	4	CC02	1	1	2025-10-05 12:17:48.515639	2025-10-05 12:17:48.515639
48	39	Storage	4	CC02	3	1	2025-10-05 12:18:59.292775	2025-10-05 12:18:59.292775
49	47	Storage	4	CC02	1	1	2025-10-05 12:20:21.534144	2025-10-05 12:20:21.534144
50	38	Storage	4	CC02	1	1	2025-10-05 12:21:27.574557	2025-10-05 12:21:27.574557
51	49	Storage	4	CB01	1	1	2025-10-05 13:45:38.587488	2025-10-05 13:45:38.587488
52	53	Storage	4	CF03	3	1	2025-10-05 14:04:26.420425	2025-10-05 14:04:26.420425
53	53	Storage	4	CF04	3	1	2025-10-05 14:04:42.529515	2025-10-05 14:04:42.529515
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.orders (id, name, description, "time", created_at, updated_at, user_id, checked_by_id, checked_at, checked, quotes_submitted_at, quotes_submitted_by_id, approved, approved_by_id, approved_at, status) FROM stdin;
63	clutch	\N	\N	2025-10-04 09:04:52.297915	2025-10-04 09:06:49.636024	1	1	2025-10-04 09:05:19.845915	t	2025-10-04 09:06:32.871036	1	approved	1	2025-10-04 09:06:49.638621	4
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.payments (id, company, body, bank, account, paid_by_id, created_at, updated_at, order_id, amount, from_account, currency, quote_id) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.products (id, code, desctription, category, product_type, created_at, updated_at) FROM stdin;
25	P550779	\N	spare	Oil filter	2025-10-03 15:39:55.162556	2025-10-03 16:04:54.28479
35	P829332	\N	spare	Air Filter	2025-10-03 16:05:49.296576	2025-10-03 16:05:49.30127
36	SU29301	\N	spare	Air Filter	2025-10-03 16:06:39.552777	2025-10-03 16:06:52.751962
37	P827653	\N	spare	Air Filter	2025-10-03 16:08:06.324594	2025-10-03 16:08:06.331922
40	TA32591	\N	spare	Air Filter	2025-10-05 08:27:21.303928	2025-10-05 08:27:21.30968
39	RE596661	\N	spare	Oil filter	2025-10-05 08:25:11.268506	2025-10-05 11:33:12.134942
41	RE284091	\N	spare	Air Filter	2025-10-05 08:28:57.787391	2025-10-05 11:34:34.896856
42	RE333567	\N	spare	Air Filter	2025-10-05 11:36:09.618121	2025-10-05 11:36:09.64454
9	P958669	\N	spare	Air Filter	2025-10-03 14:50:53.833056	2025-10-03 14:53:58.400512
10	P958671	\N	spare	Air Filter	2025-10-03 14:55:57.714236	2025-10-03 14:55:57.72457
11	AL232855	\N	spare	Alternator	2025-10-03 14:57:19.991828	2025-10-03 14:57:20.002788
12	P958404	\N	spare	Oil filter	2025-10-03 14:59:24.997327	2025-10-03 14:59:25.002834
13	P502392	\N	spare	Fuel Filter	2025-10-03 15:00:56.663745	2025-10-03 15:00:56.67298
14	P764668	\N	spare	Oil filter	2025-10-03 15:02:28.917044	2025-10-03 15:02:28.921372
43	AT365869	\N	spare	Fuel Filter	2025-10-05 11:40:38.853693	2025-10-05 11:40:38.905899
16	L214634	\N	spare	Air Filter	2025-10-03 15:05:17.234968	2025-10-03 15:05:17.242051
15	L209778	\N	spare	Air Filter	2025-10-03 15:04:04.125397	2025-10-03 15:05:55.948983
17	AL222147	\N	spare	Kingpin	2025-10-03 15:09:10.952298	2025-10-03 15:09:11.757956
18	P551432	\N	spare	Fuel Filter	2025-10-03 15:13:44.952766	2025-10-03 15:13:44.961729
44	RE269061	\N	spare	Oil filter	2025-10-05 11:48:13.420202	2025-10-05 11:48:13.446778
20	P772580	\N	spare	Air Filter	2025-10-03 15:31:52.50879	2025-10-03 15:31:52.515429
21	P775302	\N	spare	Air Filter	2025-10-03 15:33:17.481369	2025-10-03 15:33:17.486546
22	SJ26261	\N	spare	Fuel Filter	2025-10-03 15:34:33.288359	2025-10-03 15:34:33.292936
23	SJ28834	\N	spare	Oil filter	2025-10-03 15:35:34.70276	2025-10-03 15:35:34.708132
19	P551424	\N	spare	Fuel Filter	2025-10-03 15:20:10.944877	2025-10-03 15:38:15.830732
45	H216169	\N	spare	Fuel System	2025-10-05 11:59:01.233064	2025-10-05 11:59:01.262663
26	AL222225	\N	component	Cylinder	2025-10-03 15:42:59.334568	2025-10-03 15:42:59.339432
27	PH85251032	\N	component	Controller	2025-10-03 15:43:59.684277	2025-10-03 15:43:59.689065
28	VPG1410	\N	component	Clutch	2025-10-03 15:45:30.656474	2025-10-03 15:45:30.661871
29	RE258872	\N	component	Clutch	2025-10-03 15:46:26.415582	2025-10-03 15:46:26.420228
30	R177349	\N	component	Lamp	2025-10-03 15:48:13.128263	2025-10-03 15:48:13.132515
31	RE60021	\N	spare	Fuel Filter	2025-10-03 15:49:23.736126	2025-10-03 15:49:23.742416
32	P576918	\N	spare	Fuel Filter	2025-10-03 15:50:46.320622	2025-10-03 15:50:46.328424
33	RE519626	\N	spare	Oil filter	2025-10-03 15:59:05.58025	2025-10-03 15:59:05.586189
46	RE593819	\N	spare	Air Filter	2025-10-05 12:02:45.008478	2025-10-05 12:02:45.034749
34	P550758	\N	spare	Oil filter	2025-10-03 16:00:03.354382	2025-10-03 16:00:28.870995
24	P165877	\N	spare	Oil filter	2025-10-03 15:36:47.326564	2025-10-03 16:03:19.579149
47	RE596318	\N	spare	Air Filter	2025-10-05 12:06:37.685946	2025-10-05 12:06:37.709491
48	RE333569	\N	spare	Air Filter	2025-10-05 12:15:01.471443	2025-10-05 12:15:01.502118
38	RE596317	\N	spare	Air Filter	2025-10-05 08:23:25.07513	2025-10-05 12:20:46.288132
49	DZ112918	\N	spare	Fuel Filter	2025-10-05 12:22:47.097578	2025-10-05 12:22:47.116047
50	PS576926	\N	spare	Fuel Filter	2025-10-05 13:47:12.080947	2025-10-05 13:47:12.096712
51	P550938	\N	spare	Oil filter	2025-10-05 13:49:57.996828	2025-10-05 13:49:58.002371
52	P552952	\N	spare	Fuel Filter	2025-10-05 13:54:18.802919	2025-10-05 13:54:18.808181
53	RE566976	\N	component	Traction System	2025-10-05 14:04:00.563627	2025-10-05 14:04:00.571743
54	R565454	\N	component	Traction System	2025-10-05 14:05:50.550092	2025-10-05 14:05:50.553599
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.quotes (id, order_id, company, company_address, body, requested_by_id, created_at, updated_at, po_number, buy_as) FROM stdin;
75	63	other company	italy	\N	1	2025-10-04 09:06:02.908138	2025-10-04 09:06:02.91748	\N	MF
74	63	some company	cape town	\N	1	2025-10-04 09:05:40.956145	2025-10-04 09:06:49.621176	POMF250001	MF
\.


--
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.requests (id, order_id, product_id, quantity, created_at, updated_at) FROM stdin;
22	63	29	1	2025-10-04 09:05:16.819575	2025-10-04 09:05:16.819575
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.schema_migrations (version) FROM stdin;
20250807090753
20250807145509
20250808065232
20250814084502
20250814091809
20250814123623
20250814124220
20250814130811
20250814154345
20250814154526
20250815093644
20250815095953
20250815121316
20250815121756
20250815125122
20250815145310
20250816130744
20250816132458
20250819112928
20250819131242
20250822072722
20250822073407
20250822075737
20250822082911
20250822090546
20250822135954
20250822144041
20250824072733
20250824123428
20250825125436
20250825140436
20250826162411
20250827151912
20250827155716
20250827160555
20250827161024
20250829093800
20250829094448
20250829130905
20250829185251
20250829190356
20250830222259
20250911144927
20250911150437
20250911150640
20250917140522
20251002123710
20251003083516
20251003115920
20251003120001
\.


--
-- Data for Name: stocks; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.stocks (id, product_id, quantity, storage_type, storage_id, created_at, updated_at, location) FROM stdin;
59	53	3	Storage	4	2025-10-05 14:04:26.432105	2025-10-05 14:04:26.432105	CF03
60	53	3	Storage	4	2025-10-05 14:04:42.53331	2025-10-05 14:04:42.53331	CF04
61	54	15	Storage	4	2025-10-05 14:05:50.558856	2025-10-05 14:05:50.558856	CF04
5	9	4	Storage	4	2025-10-03 14:54:57.865212	2025-10-03 14:54:57.865212	CD01
6	10	4	Storage	4	2025-10-03 14:56:27.462114	2025-10-03 14:56:27.462114	CD01
7	11	1	Storage	4	2025-10-03 14:57:34.277621	2025-10-03 14:57:34.277621	CD01
8	12	2	Storage	4	2025-10-03 14:59:51.667699	2025-10-03 14:59:51.667699	CD01
9	13	3	Storage	4	2025-10-03 15:01:22.041842	2025-10-03 15:01:22.041842	CD01
10	14	2	Storage	4	2025-10-03 15:03:03.596031	2025-10-03 15:03:03.596031	CD01
11	15	4	Storage	4	2025-10-03 15:04:20.686877	2025-10-03 15:04:20.686877	CD01
12	16	2	Storage	4	2025-10-03 15:05:33.90739	2025-10-03 15:05:33.90739	CD01
13	17	2	Storage	4	2025-10-03 15:09:44.532507	2025-10-03 15:09:44.532507	CD01
14	18	4	Storage	4	2025-10-03 15:14:14.123347	2025-10-03 15:14:14.123347	CD02
15	19	4	Storage	4	2025-10-03 15:20:30.13829	2025-10-03 15:20:30.13829	CD02
16	20	2	Storage	4	2025-10-03 15:32:21.513457	2025-10-03 15:32:21.513457	CE01
17	21	2	Storage	4	2025-10-03 15:33:33.806876	2025-10-03 15:33:33.806876	CE01
18	22	2	Storage	4	2025-10-03 15:34:51.960741	2025-10-03 15:34:51.960741	CE01
19	23	3	Storage	4	2025-10-03 15:35:52.408701	2025-10-03 15:35:52.408701	CE01
20	24	2	Storage	4	2025-10-03 15:37:06.454615	2025-10-03 15:37:06.454615	CE01
21	19	2	Storage	4	2025-10-03 15:38:55.431585	2025-10-03 15:38:55.431585	CE01
22	25	1	Storage	4	2025-10-03 15:40:49.310645	2025-10-03 15:40:49.310645	CE01
23	26	1	Storage	4	2025-10-03 15:43:24.312922	2025-10-03 15:43:24.312922	CE01
24	27	1	Storage	4	2025-10-03 15:44:17.450513	2025-10-03 15:44:17.450513	CE01
25	28	1	Storage	4	2025-10-03 15:45:47.193685	2025-10-03 15:45:47.193685	CE01
26	29	1	Storage	4	2025-10-03 15:46:43.416144	2025-10-03 15:46:43.416144	CE02
27	30	1	Storage	4	2025-10-03 15:48:37.402021	2025-10-03 15:48:37.402021	CE02
28	31	1	Storage	4	2025-10-03 15:49:41.355688	2025-10-03 15:49:41.355688	CE02
29	32	1	Storage	4	2025-10-03 15:52:06.189668	2025-10-03 15:52:06.189668	CE02
30	33	1	Storage	4	2025-10-03 15:59:24.367035	2025-10-03 15:59:24.367035	CE02
31	34	1	Storage	4	2025-10-03 16:00:45.248008	2025-10-03 16:00:45.248008	CE02
32	24	3	Storage	4	2025-10-03 16:03:40.001077	2025-10-03 16:03:40.001077	CE02
33	35	1	Storage	4	2025-10-03 16:06:14.213577	2025-10-03 16:06:14.213577	CE02
34	36	1	Storage	4	2025-10-03 16:07:13.872519	2025-10-03 16:07:13.872519	CE02
35	37	3	Storage	4	2025-10-03 16:08:39.682525	2025-10-03 16:08:39.682525	CE02
37	38	1	Storage	4	2025-10-05 08:23:25.206518	2025-10-05 09:39:35.838729	CC01
38	39	3	Storage	4	2025-10-05 08:25:11.351391	2025-10-05 09:39:43.28211	CC01
40	41	2	Storage	4	2025-10-05 08:28:57.80941	2025-10-05 09:41:19.570952	CC01
39	40	1	Storage	4	2025-10-05 08:27:21.321875	2025-10-05 09:41:27.399611	CC01
41	42	1	Storage	4	2025-10-05 11:38:34.02623	2025-10-05 11:38:34.02623	CC01
42	43	2	Storage	4	2025-10-05 11:47:13.399738	2025-10-05 11:47:13.399738	CC01
43	44	2	Storage	4	2025-10-05 11:50:58.97627	2025-10-05 11:50:58.97627	CC01
44	45	2	Storage	4	2025-10-05 12:01:11.077013	2025-10-05 12:01:11.077013	CC01
45	46	2	Storage	4	2025-10-05 12:05:15.703361	2025-10-05 12:05:15.703361	CC01
46	47	1	Storage	4	2025-10-05 12:10:51.145666	2025-10-05 12:10:51.145666	CC01
47	46	2	Storage	4	2025-10-05 12:11:37.469746	2025-10-05 12:11:37.469746	CC02
48	42	2	Storage	4	2025-10-05 12:12:35.459659	2025-10-05 12:12:50.975954	CC02
49	41	1	Storage	4	2025-10-05 12:13:59.677794	2025-10-05 12:13:59.677794	CC02
50	48	1	Storage	4	2025-10-05 12:17:48.724986	2025-10-05 12:17:48.724986	CC02
51	39	3	Storage	4	2025-10-05 12:18:59.306266	2025-10-05 12:18:59.306266	CC02
52	47	1	Storage	4	2025-10-05 12:20:21.540615	2025-10-05 12:20:21.540615	CC02
53	38	1	Storage	4	2025-10-05 12:21:27.583753	2025-10-05 12:21:27.583753	CC02
54	49	1	Storage	4	2025-10-05 13:45:38.620544	2025-10-05 13:45:38.620544	CB01
55	50	2	Storage	4	2025-10-05 13:47:12.13644	2025-10-05 13:47:12.13644	CB01
56	51	2	Storage	4	2025-10-05 13:49:58.008672	2025-10-05 13:49:58.008672	CB01
57	52	2	Storage	4	2025-10-05 13:54:18.813132	2025-10-05 13:54:18.813132	CB01
58	53	1	Storage	4	2025-10-05 14:04:00.576634	2025-10-05 14:04:00.576634	CF02
\.


--
-- Data for Name: storages; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.storages (id, name, abbreviation, created_at, updated_at) FROM stdin;
4	Machiya Main Storage	Y01	2025-10-03 14:42:20.162002	2025-10-03 14:42:20.162002
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at, user_type) FROM stdin;
1	director@mutanda.com	$2a$12$EjyMpkLmh0W2ZV9rEZrgQuv3nesp0A6mXSViRgCdKirY3LZ8OeYHi	\N	\N	\N	2025-08-07 18:49:46.247407	2025-08-07 19:35:40.817537	director
2	manager@mutanda.com	$2a$12$Yxk0j8VV2KCK9vEmoc1skOWFlwP5qkFNj0gfQeZ8hX63bn5xlQ/ry	\N	\N	\N	2025-08-07 19:36:46.321346	2025-08-07 19:36:46.321346	manager
3	cashier@mutanda.com	$2a$12$kgLUSrqBOYzvrZYriTUnDuMVZ.nUB9aF6K7C2Y8Khtpcs6N6TZgL2	\N	\N	\N	2025-08-07 20:00:38.794063	2025-08-07 20:00:38.794063	cashier
4	worker@mutanda.com	$2a$12$X6x7Z0UrKS3gqfSClcILn.bB5UpDOqh2bsmWxz8IFft8qPTTXHM2u	\N	\N	\N	2025-08-07 20:01:07.858118	2025-08-07 20:01:07.858118	worker
5	worker1@mutanda.com	$2a$12$fD9KSdsfNFU8g0yjO6suwuIPjG9vVtBPWIkbI.FBC4AGIoBxPd0KO	\N	\N	\N	2025-08-14 13:37:40.908391	2025-08-14 13:37:40.908391	worker
6	cashier1@mutanda.com	$2a$12$/F5r3ZNcNbOSEkG8./obJeWjCTWuYUaI6CnFXPfzLT3pyzzp86IsW	\N	\N	\N	2025-08-15 17:24:10.505681	2025-08-15 17:24:10.505681	cashier
7	procurement@mutanda.com	$2a$12$VpsWDeXBeXc/WKEdB5WL..Fm.JnPQd/61bgHhqsLcZO9KWrs8lPbS	\N	\N	\N	2025-08-15 17:29:57.141421	2025-08-15 17:29:57.141421	procurement
8	director1@mutanda.com	$2a$12$eMcpaM06WUxhXPzTRAgGd.vfV2gYJIw1SBKXLsnWHU1ySSAdnjc3u	\N	\N	\N	2025-08-29 10:31:28.146346	2025-08-29 10:31:28.146346	director
\.


--
-- Name: action_text_rich_texts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.action_text_rich_texts_id_seq', 246, true);


--
-- Name: active_storage_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.active_storage_attachments_id_seq', 9, true);


--
-- Name: active_storage_blobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.active_storage_blobs_id_seq', 10, true);


--
-- Name: active_storage_variant_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.active_storage_variant_records_id_seq', 4, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.comments_id_seq', 8, true);


--
-- Name: delivery_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.delivery_notes_id_seq', 18, true);


--
-- Name: goods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.goods_id_seq', 20, true);


--
-- Name: issue_slip_articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.issue_slip_articles_id_seq', 7, true);


--
-- Name: issue_slips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.issue_slips_id_seq', 4, true);


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.items_id_seq', 118, true);


--
-- Name: manual_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.manual_entries_id_seq', 53, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.orders_id_seq', 63, true);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.payments_id_seq', 31, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.products_id_seq', 54, true);


--
-- Name: quotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.quotes_id_seq', 75, true);


--
-- Name: requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.requests_id_seq', 22, true);


--
-- Name: stocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.stocks_id_seq', 61, true);


--
-- Name: storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.storages_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.users_id_seq', 8, true);


--
-- Name: action_text_rich_texts action_text_rich_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.action_text_rich_texts
    ADD CONSTRAINT action_text_rich_texts_pkey PRIMARY KEY (id);


--
-- Name: active_storage_attachments active_storage_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT active_storage_attachments_pkey PRIMARY KEY (id);


--
-- Name: active_storage_blobs active_storage_blobs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.active_storage_blobs
    ADD CONSTRAINT active_storage_blobs_pkey PRIMARY KEY (id);


--
-- Name: active_storage_variant_records active_storage_variant_records_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT active_storage_variant_records_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: delivery_notes delivery_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.delivery_notes
    ADD CONSTRAINT delivery_notes_pkey PRIMARY KEY (id);


--
-- Name: goods goods_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.goods
    ADD CONSTRAINT goods_pkey PRIMARY KEY (id);


--
-- Name: issue_slip_articles issue_slip_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slip_articles
    ADD CONSTRAINT issue_slip_articles_pkey PRIMARY KEY (id);


--
-- Name: issue_slips issue_slips_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slips
    ADD CONSTRAINT issue_slips_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: manual_entries manual_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.manual_entries
    ADD CONSTRAINT manual_entries_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: stocks stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT stocks_pkey PRIMARY KEY (id);


--
-- Name: storages storages_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT storages_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_action_text_rich_texts_uniqueness; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX index_action_text_rich_texts_uniqueness ON public.action_text_rich_texts USING btree (record_type, record_id, name);


--
-- Name: index_active_storage_attachments_on_blob_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_active_storage_attachments_on_blob_id ON public.active_storage_attachments USING btree (blob_id);


--
-- Name: index_active_storage_attachments_uniqueness; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX index_active_storage_attachments_uniqueness ON public.active_storage_attachments USING btree (record_type, record_id, name, blob_id);


--
-- Name: index_active_storage_blobs_on_key; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX index_active_storage_blobs_on_key ON public.active_storage_blobs USING btree (key);


--
-- Name: index_active_storage_variant_records_uniqueness; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX index_active_storage_variant_records_uniqueness ON public.active_storage_variant_records USING btree (blob_id, variation_digest);


--
-- Name: index_comments_on_order_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_comments_on_order_id ON public.comments USING btree (order_id);


--
-- Name: index_comments_on_user_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_comments_on_user_id ON public.comments USING btree (user_id);


--
-- Name: index_delivery_notes_on_order_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_delivery_notes_on_order_id ON public.delivery_notes USING btree (order_id);


--
-- Name: index_delivery_notes_on_quote_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_delivery_notes_on_quote_id ON public.delivery_notes USING btree (quote_id);


--
-- Name: index_delivery_notes_on_recieved_by_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_delivery_notes_on_recieved_by_id ON public.delivery_notes USING btree (recieved_by_id);


--
-- Name: index_goods_on_delivery_note_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_goods_on_delivery_note_id ON public.goods USING btree (delivery_note_id);


--
-- Name: index_issue_slip_articles_on_issue_slip_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_issue_slip_articles_on_issue_slip_id ON public.issue_slip_articles USING btree (issue_slip_id);


--
-- Name: index_issue_slip_articles_on_product_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_issue_slip_articles_on_product_id ON public.issue_slip_articles USING btree (product_id);


--
-- Name: index_issue_slip_articles_on_storage_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_issue_slip_articles_on_storage_id ON public.issue_slip_articles USING btree (storage_id);


--
-- Name: index_issue_slips_on_collected_by_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_issue_slips_on_collected_by_id ON public.issue_slips USING btree (collected_by_id);


--
-- Name: index_issue_slips_on_created_by_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_issue_slips_on_created_by_id ON public.issue_slips USING btree (created_by_id);


--
-- Name: index_issue_slips_on_issued_by_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_issue_slips_on_issued_by_id ON public.issue_slips USING btree (issued_by_id);


--
-- Name: index_issue_slips_on_number; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX index_issue_slips_on_number ON public.issue_slips USING btree (number);


--
-- Name: index_issue_slips_on_order_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_issue_slips_on_order_id ON public.issue_slips USING btree (order_id);


--
-- Name: index_items_on_product_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_items_on_product_id ON public.items USING btree (product_id);


--
-- Name: index_items_on_quote_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_items_on_quote_id ON public.items USING btree (quote_id);


--
-- Name: index_manual_entries_on_product_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_manual_entries_on_product_id ON public.manual_entries USING btree (product_id);


--
-- Name: index_manual_entries_on_storage; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_manual_entries_on_storage ON public.manual_entries USING btree (storage_type, storage_id);


--
-- Name: index_manual_entries_on_user_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_manual_entries_on_user_id ON public.manual_entries USING btree (user_id);


--
-- Name: index_orders_on_approved_by_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_orders_on_approved_by_id ON public.orders USING btree (approved_by_id);


--
-- Name: index_orders_on_checked_by_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_orders_on_checked_by_id ON public.orders USING btree (checked_by_id);


--
-- Name: index_orders_on_quotes_submitted_by_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_orders_on_quotes_submitted_by_id ON public.orders USING btree (quotes_submitted_by_id);


--
-- Name: index_orders_on_user_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_orders_on_user_id ON public.orders USING btree (user_id);


--
-- Name: index_payments_on_order_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_payments_on_order_id ON public.payments USING btree (order_id);


--
-- Name: index_payments_on_paid_by_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_payments_on_paid_by_id ON public.payments USING btree (paid_by_id);


--
-- Name: index_payments_on_quote_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_payments_on_quote_id ON public.payments USING btree (quote_id);


--
-- Name: index_quotes_on_order_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_quotes_on_order_id ON public.quotes USING btree (order_id);


--
-- Name: index_quotes_on_requested_by_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_quotes_on_requested_by_id ON public.quotes USING btree (requested_by_id);


--
-- Name: index_requests_on_order_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_requests_on_order_id ON public.requests USING btree (order_id);


--
-- Name: index_requests_on_product_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_requests_on_product_id ON public.requests USING btree (product_id);


--
-- Name: index_stocks_on_product_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_stocks_on_product_id ON public.stocks USING btree (product_id);


--
-- Name: index_stocks_on_storage; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX index_stocks_on_storage ON public.stocks USING btree (storage_type, storage_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: comments fk_rails_03de2dc08c; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT fk_rails_03de2dc08c FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: issue_slip_articles fk_rails_0560412ab3; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slip_articles
    ADD CONSTRAINT fk_rails_0560412ab3 FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: delivery_notes fk_rails_095142629a; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.delivery_notes
    ADD CONSTRAINT fk_rails_095142629a FOREIGN KEY (recieved_by_id) REFERENCES public.users(id);


--
-- Name: manual_entries fk_rails_174d9aa5e2; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.manual_entries
    ADD CONSTRAINT fk_rails_174d9aa5e2 FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: delivery_notes fk_rails_2319905b3f; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.delivery_notes
    ADD CONSTRAINT fk_rails_2319905b3f FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: requests fk_rails_2f24c9d415; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT fk_rails_2f24c9d415 FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: quotes fk_rails_2f6c208eb7; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT fk_rails_2f6c208eb7 FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: items fk_rails_417636de51; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_rails_417636de51 FOREIGN KEY (quote_id) REFERENCES public.quotes(id);


--
-- Name: comments fk_rails_453b7b85cf; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT fk_rails_453b7b85cf FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: delivery_notes fk_rails_537f432a23; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.delivery_notes
    ADD CONSTRAINT fk_rails_537f432a23 FOREIGN KEY (quote_id) REFERENCES public.quotes(id);


--
-- Name: issue_slips fk_rails_6225e3e1ca; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slips
    ADD CONSTRAINT fk_rails_6225e3e1ca FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: issue_slips fk_rails_65353be408; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slips
    ADD CONSTRAINT fk_rails_65353be408 FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: issue_slips fk_rails_659295c350; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slips
    ADD CONSTRAINT fk_rails_659295c350 FOREIGN KEY (collected_by_id) REFERENCES public.users(id);


--
-- Name: issue_slips fk_rails_696d00bd8d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slips
    ADD CONSTRAINT fk_rails_696d00bd8d FOREIGN KEY (issued_by_id) REFERENCES public.users(id);


--
-- Name: issue_slip_articles fk_rails_69db23ffa1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slip_articles
    ADD CONSTRAINT fk_rails_69db23ffa1 FOREIGN KEY (storage_id) REFERENCES public.storages(id);


--
-- Name: payments fk_rails_6af949464b; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT fk_rails_6af949464b FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: payments fk_rails_82ae4e0bc4; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT fk_rails_82ae4e0bc4 FOREIGN KEY (paid_by_id) REFERENCES public.users(id);


--
-- Name: orders fk_rails_9335b2661a; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_rails_9335b2661a FOREIGN KEY (checked_by_id) REFERENCES public.users(id);


--
-- Name: quotes fk_rails_934693c1f7; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT fk_rails_934693c1f7 FOREIGN KEY (requested_by_id) REFERENCES public.users(id);


--
-- Name: active_storage_variant_records fk_rails_993965df05; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.active_storage_variant_records
    ADD CONSTRAINT fk_rails_993965df05 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: items fk_rails_9a56345cfd; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT fk_rails_9a56345cfd FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: manual_entries fk_rails_9aca990a5f; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.manual_entries
    ADD CONSTRAINT fk_rails_9aca990a5f FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: goods fk_rails_9e8d598b9a; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.goods
    ADD CONSTRAINT fk_rails_9e8d598b9a FOREIGN KEY (delivery_note_id) REFERENCES public.delivery_notes(id);


--
-- Name: issue_slip_articles fk_rails_ab08e0f700; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.issue_slip_articles
    ADD CONSTRAINT fk_rails_ab08e0f700 FOREIGN KEY (issue_slip_id) REFERENCES public.issue_slips(id);


--
-- Name: requests fk_rails_b30d4199d6; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT fk_rails_b30d4199d6 FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: active_storage_attachments fk_rails_c3b3935057; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.active_storage_attachments
    ADD CONSTRAINT fk_rails_c3b3935057 FOREIGN KEY (blob_id) REFERENCES public.active_storage_blobs(id);


--
-- Name: stocks fk_rails_cfc800c26b; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT fk_rails_cfc800c26b FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: orders fk_rails_ed4a17f357; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_rails_ed4a17f357 FOREIGN KEY (quotes_submitted_by_id) REFERENCES public.users(id);


--
-- Name: payments fk_rails_f14274b07a; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT fk_rails_f14274b07a FOREIGN KEY (quote_id) REFERENCES public.quotes(id);


--
-- Name: orders fk_rails_f61cd6af2c; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_rails_f61cd6af2c FOREIGN KEY (approved_by_id) REFERENCES public.users(id);


--
-- Name: orders fk_rails_f868b47f6a; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_rails_f868b47f6a FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict LT9PoGdGR7qvcqVqdFYSx1tcxcPSOuFm2EQbDjZzWrAd2dBpvvY6v02aqPhjwMu

